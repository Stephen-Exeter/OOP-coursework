package cityrescue.exceptions;
public class InvalidGridException extends Exception { public InvalidGridException(String message){ super(message);} }

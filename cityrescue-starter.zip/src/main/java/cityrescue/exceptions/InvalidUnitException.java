package cityrescue.exceptions;
public class InvalidUnitException extends Exception { public InvalidUnitException(String message){ super(message);} }

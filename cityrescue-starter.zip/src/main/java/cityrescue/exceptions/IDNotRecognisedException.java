package cityrescue.exceptions;
public class IDNotRecognisedException extends Exception { public IDNotRecognisedException(String message){ super(message);} }

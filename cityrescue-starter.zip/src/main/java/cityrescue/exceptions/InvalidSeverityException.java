package cityrescue.exceptions;
public class InvalidSeverityException extends Exception { public InvalidSeverityException(String message){ super(message);} }

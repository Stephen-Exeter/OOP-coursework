package cityrescue.enums;
public enum IncidentStatus { REPORTED, DISPATCHED, IN_PROGRESS, RESOLVED, CANCELLED }

package cityrescue.enums;
public enum UnitStatus { IDLE, EN_ROUTE, AT_SCENE, OUT_OF_SERVICE }

package cityrescue.enums;
public enum UnitType { AMBULANCE, FIRE_ENGINE, POLICE_CAR }

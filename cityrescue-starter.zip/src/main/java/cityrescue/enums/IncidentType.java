package cityrescue.enums;
public enum IncidentType { MEDICAL, FIRE, CRIME }
